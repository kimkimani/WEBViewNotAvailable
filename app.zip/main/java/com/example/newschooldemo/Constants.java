package com.example.newschooldemo;

/**
 * Created by Saurabhk on 02/06/2017.
 */

public class Constants {

    public  static  String subject="";
    public  static  int image=0;
    public  static  int bgColor=0;
}
